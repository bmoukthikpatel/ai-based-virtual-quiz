#!/usr/bin/env python3
"""
Quiz Engine Module
Core quiz logic and game loop for the AI-based quiz system.
"""

import cv2
import time
import os
from collections import deque

from hand_detection import (
    detect_hand_landmarks, 
    get_finger_position, 
    check_finger_in_box, 
    check_selected_option,
    detect_drawing_gesture,
    calculate_distance
)
import mediapipe as mp
from ui_components import (
    display_question, 
    display_timer, 
    create_finish_button, 
    draw_drawing_points,
    display_result
)
from file_utils import (
    load_questions, 
    setup_responses_directory, 
    save_drawing, 
    log_responses
)


class QuizEngine:
    """Main quiz engine class that handles the quiz flow and logic."""
    
    def __init__(self, quiz_file="quiz.txt"):
        """
        Initialize the quiz engine.
        
        Args:
            quiz_file (str): Path to the quiz questions file
        """
        self.quiz_file = quiz_file
        self.questions = load_questions(quiz_file)
        self.responses_dir = setup_responses_directory()
        self.total_questions = len(self.questions)
        self.score = 0
        self.current_question = 0
        self.mcq_responses = []
        self.draw_responses = []
        self.quiz_finished_by_button = False
        
        # Initialize video capture
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            raise RuntimeError("Could not open camera")
    
    def run(self):
        """Run the main quiz loop."""
        if not self.questions:
            print("No questions found or error reading quiz.txt")
            return
        
        with open(os.path.join(self.responses_dir, "responses.txt"), "w") as log_file:
            while self.current_question < self.total_questions:
                self._run_question()
                
                # Check if quiz was finished by button
                if self.quiz_finished_by_button:
                    break
                
                self.current_question += 1
            
            # Display final results
            self._display_final_results(log_file)
        
        self.cap.release()
        cv2.destroyAllWindows()
    
    def _run_question(self):
        """Run a single question."""
        start_time = time.time()
        option_selected = None
        confirmation_start_time = None
        finish_confirmation_start_time = None
        drawing_points = []
        smoothing_window = deque(maxlen=10)
        distance_window = deque(maxlen=5)
        drawing_active = False
        stable_frames = 0
        
        while time.time() - start_time < 15:  # 15-second timer
            ret, frame = self.cap.read()
            if not ret:
                break
            
            flipped_frame = cv2.flip(frame, 1)
            frame_height, frame_width, _ = flipped_frame.shape
            hand_landmarks = detect_hand_landmarks(flipped_frame)
            
            # Create finish button
            finish_button_box = create_finish_button(flipped_frame)
            
            if hand_landmarks:
                index_tip_coords = get_finger_position(hand_landmarks, flipped_frame.shape)
                
                # Handle finish button interaction
                is_on_finish = check_finger_in_box(index_tip_coords[0], index_tip_coords[1], finish_button_box)
                if is_on_finish:
                    if finish_confirmation_start_time is None:
                        finish_confirmation_start_time = time.time()
                    elif time.time() - finish_confirmation_start_time >= 1.5:
                        self.quiz_finished_by_button = True
                        break
                else:
                    finish_confirmation_start_time = None
                
                # Handle question-specific logic
                if self.questions[self.current_question]["keyword"] == "mcq":
                    option_selected, confirmation_start_time = self._handle_mcq_question(
                        flipped_frame, hand_landmarks, index_tip_coords, option_selected, confirmation_start_time, start_time
                    )
                    # Break if option is confirmed
                    if option_selected and confirmation_start_time is None:
                        break
                else:
                    drawing_points, stable_frames = self._handle_drawing_question(
                        hand_landmarks, flipped_frame.shape, distance_window, smoothing_window, 
                        drawing_points, stable_frames
                    )
            
            # Draw UI elements
            self._draw_ui_elements(flipped_frame, drawing_points, option_selected, start_time)
            
            # Handle quit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.cap.release()
                cv2.destroyAllWindows()
                return
        
        # Log responses for current question
        self._log_current_question_response(drawing_points, option_selected)
    

    
    def _handle_mcq_question(self, flipped_frame, hand_landmarks, index_tip_coords, option_selected, confirmation_start_time, start_time):
        """Handle MCQ question logic."""
        option_boxes = display_question(
            flipped_frame, self.questions[self.current_question],
            int(15 - (time.time() - start_time)),
            self.current_question + 1, self.total_questions, option_selected
        )
        
        selected_option = check_selected_option(index_tip_coords[0], index_tip_coords[1], option_boxes)
        
        if selected_option:
            if option_selected == selected_option:
                if confirmation_start_time and time.time() - confirmation_start_time >= 1.5:
                    if selected_option == self.questions[self.current_question]["answer"]:
                        self.score += 1
                    return option_selected, None
            else:
                option_selected = selected_option
                confirmation_start_time = time.time()
        else:
            option_selected = None
            confirmation_start_time = None
        
        return option_selected, confirmation_start_time
    
    def _handle_drawing_question(self, hand_landmarks, frame_shape, distance_window, smoothing_window, drawing_points, stable_frames):
        """Handle drawing question logic."""
        # Get thumb and index finger positions directly like in original
        thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]
        index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
        frame_height, frame_width, _ = frame_shape
        thumb_tip_coords = (int(thumb_tip.x * frame_width), int(thumb_tip.y * frame_height))
        index_tip_coords = (int(index_tip.x * frame_width), int(index_tip.y * frame_height))
        
        # Calculate distance and check for pinch gesture
        distance = calculate_distance(thumb_tip_coords, index_tip_coords)
        distance_window.append(distance)
        avg_distance = np.mean(distance_window)
        threshold = 30
        
        if avg_distance < threshold:
            stable_frames += 1
            if stable_frames > 2:
                smoothing_window.append(index_tip_coords)
                if len(smoothing_window) == smoothing_window.maxlen:
                    smoothed_point = tuple(np.mean(smoothing_window, axis=0).astype(int))
                    drawing_points.append(smoothed_point)
        else:
            stable_frames = 0
            smoothing_window.clear()
            if len(drawing_points) > 0 and drawing_points[-1] is not None:
                drawing_points.append(None)
        
        return drawing_points, stable_frames
    
    def _draw_ui_elements(self, flipped_frame, drawing_points, option_selected, start_time):
        """Draw all UI elements on the frame."""
        # Draw drawing points
        draw_drawing_points(flipped_frame, drawing_points)
        
        # Display question
        if self.questions[self.current_question]["keyword"] == "mcq":
            display_question(
                flipped_frame, self.questions[self.current_question],
                int(15 - (time.time() - start_time)),
                self.current_question + 1, self.total_questions, option_selected
            )
        else:
            display_question(
                flipped_frame, self.questions[self.current_question],
                int(15 - (time.time() - start_time)),
                self.current_question + 1, self.total_questions
            )
        
        # Display timer
        display_timer(flipped_frame, int(15 - (time.time() - start_time)))
        
        cv2.imshow("AI-Based Quiz", flipped_frame)
    
    def _log_current_question_response(self, drawing_points, option_selected):
        """Log the response for the current question."""
        if self.questions[self.current_question]["keyword"] == "mcq":
            correct_option = self.questions[self.current_question]["answer"]
            if option_selected:
                self.mcq_responses.append(
                    f"Question {self.current_question + 1}: {option_selected} (correct option is {correct_option})"
                )
            else:
                self.mcq_responses.append(
                    f"Question {self.current_question + 1}: not attempted (correct option is {correct_option})"
                )
        else:
            if drawing_points:
                image_path = save_drawing(drawing_points, self.responses_dir, self.current_question, (480, 640, 3))
                self.draw_responses.append(f"Question {self.current_question + 1}: {image_path}")
            else:
                self.draw_responses.append(f"Question {self.current_question + 1}: not attempted")
    
    def _display_final_results(self, log_file):
        """Display and log final results."""
        has_drawing_questions = any(q["keyword"] == "draw" for q in self.questions)
        
        # Log responses
        log_responses(log_file, self.mcq_responses, self.draw_responses, self.score, len(self.mcq_responses))
        
        # Display result
        if has_drawing_questions:
            result_text = "Your responses are recorded!"
        else:
            result_text = f"Your result is {self.score}/{len(self.mcq_responses)}"
        
        display_result(result_text) 