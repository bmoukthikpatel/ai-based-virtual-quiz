#!/usr/bin/env python3
"""
Hand Detection Module
Handles MediaPipe hand tracking and gesture recognition for the AI-based quiz system.
"""

import cv2
import mediapipe as mp
import numpy as np
from collections import deque

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils


def calculate_distance(point1, point2):
    """
    Calculate Euclidean distance between two points.
    
    Args:
        point1 (tuple): First point coordinates (x, y)
        point2 (tuple): Second point coordinates (x, y)
    
    Returns:
        float: Euclidean distance between the points
    """
    return np.sqrt((point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2)


def detect_hand_landmarks(frame):
    """
    Detect hand landmarks and draw them on the frame.
    
    Args:
        frame: Input video frame
    
    Returns:
        HandLandmarks object or None if no hand detected
    """
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            return hand_landmarks
    return None


def get_finger_position(hand_landmarks, frame_shape):
    """
    Get the index finger tip position in pixel coordinates.
    
    Args:
        hand_landmarks: MediaPipe hand landmarks
        frame_shape: Shape of the video frame (height, width, channels)
    
    Returns:
        tuple: (x, y) coordinates of index finger tip
    """
    index_finger_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
    height, width, _ = frame_shape
    return int(index_finger_tip.x * width), int(index_finger_tip.y * height)


def check_finger_in_box(x, y, box):
    """
    Check if finger is in a specific box (for UI interactions).
    
    Args:
        x (int): X coordinate of finger
        y (int): Y coordinate of finger
        box (tuple): Bounding box (x1, y1, x2, y2)
    
    Returns:
        bool: True if finger is inside the box
    """
    x1, y1, x2, y2 = box
    return x1 <= x <= x2 and y1 <= y <= y2


def check_selected_option(x, y, option_boxes):
    """
    Check whether the finger position falls within any option bounding box.
    
    Args:
        x (int): X coordinate of finger
        y (int): Y coordinate of finger
        option_boxes (list): List of option bounding boxes
    
    Returns:
        str or None: Selected option letter (A, B, C, D) or None
    """
    if not option_boxes:
        return None
    for idx, box in enumerate(option_boxes):
        x1, y1, x2, y2 = box
        if x1 <= x <= x2 and y1 <= y <= y2:
            return chr(65 + idx)  # Convert to A, B, C, D
    return None


def detect_drawing_gesture(hand_landmarks, frame_shape, distance_window, smoothing_window):
    """
    Detect if user is making a drawing gesture (pinch).
    
    Args:
        hand_landmarks: MediaPipe hand landmarks
        frame_shape: Shape of the video frame
        distance_window: Deque for storing distance measurements
        smoothing_window: Deque for smoothing drawing points
    
    Returns:
        tuple: (is_drawing, smoothed_point, drawing_points)
    """
    thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]
    index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
    
    frame_height, frame_width, _ = frame_shape
    thumb_tip_coords = (int(thumb_tip.x * frame_width), int(thumb_tip.y * frame_height))
    index_tip_coords = (int(index_tip.x * frame_width), int(index_tip.y * frame_height))
    
    distance = calculate_distance(thumb_tip_coords, index_tip_coords)
    distance_window.append(distance)
    avg_distance = np.mean(distance_window)
    
    threshold = 30
    is_drawing = avg_distance < threshold
    
    if is_drawing:
        smoothing_window.append(index_tip_coords)
        if len(smoothing_window) == smoothing_window.maxlen:
            smoothed_point = tuple(np.mean(smoothing_window, axis=0).astype(int))
            return True, smoothed_point, index_tip_coords
    else:
        smoothing_window.clear()
    
    return False, None, index_tip_coords 